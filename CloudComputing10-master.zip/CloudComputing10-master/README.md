# CloudComputing10
Cloud computing project for semester

# Client 
* Client will run on port 3000 using the followng command.
* Command: npm run start

# Server
* Server will run on port 5010 using the following commend.
* Development: npm run devstart
* Production: npm run start
